# C4mail-lite
The latest version of email spam. Unlimited, spam up to 20 email accounts.

# how to run it:
$git clone https://github.com/ramahmdr/C4mail-lite

$cd C4mail-lite

$bash b00m.sh

# Password
password: bogorwanienteam

# Disclaimer !
everything the user does is not the responsibility of the tool maker.
